// Задание 2.1

import Foundation
// Входные данные
let xArray: [Double] = [3.2, 1.6, 3.6, 2.6, 6.1, 9.7, -4.9, 0.5, -3.1, -0.3, 6,5, 3.7, -5.3, -8.4]
// Решение
let xMin = xArray.minElement()
let yArray = xArray.map { ($0 * $0 * $0) / xMin! }
let iIndex = 13 // i-ый индекс для суммы массива y
let result = yArray.enumerate()
    .filter { (index, _) -> Bool in
        if (index + 1) % 2 != 0 && (index + 1) <= iIndex {
            return true
        } else {
            return false
        }
    }
    .reduce(0.0) { (total: Double, array: (index: Int, element: Double)) -> Double in
        total + array.element
    }


